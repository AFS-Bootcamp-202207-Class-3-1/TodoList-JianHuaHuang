import DoneTodoListGroup from "./DoneTodoListGroup";



export default function DoneTodoList(){
    return (
        <>
        <DoneTodoListGroup/>
        </>
    )
}